@extends('layouts.app')

@section('content')

<div class="row page-title">
    <div class="col-sm-4 col-xl-6">
        <h4 class="mb-1 mt-0">Horizontal</h4>
    </div>
</div>

@endsection